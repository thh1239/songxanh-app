package com.example.songxanh.ui.interfaces;

import android.view.View;

import com.example.songxanh.data.models.Achievement;

public interface ActionOnAchievementMenu {
    void showPopupMenu(Achievement achievement, View button);
}
