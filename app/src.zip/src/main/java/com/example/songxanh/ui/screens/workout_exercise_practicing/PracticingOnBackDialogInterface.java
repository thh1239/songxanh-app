package com.example.songxanh.ui.screens.workout_exercise_practicing;

public interface PracticingOnBackDialogInterface {
     void onPositiveButton();
     void onNegativeButton();
}
