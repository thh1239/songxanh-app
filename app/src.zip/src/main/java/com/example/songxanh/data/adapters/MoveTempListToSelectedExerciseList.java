package com.example.songxanh.data.adapters;

import com.example.songxanh.data.models.Exercise;

import java.util.List;

public interface MoveTempListToSelectedExerciseList {
    void addExerciseToTempList(Exercise exercise);
}
