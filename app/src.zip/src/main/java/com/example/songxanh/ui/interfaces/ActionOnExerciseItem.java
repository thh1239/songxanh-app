package com.example.songxanh.ui.interfaces;

import com.example.songxanh.data.models.Exercise;

public interface ActionOnExerciseItem {
    void onInformationBtn(Exercise exercise);
    void onDelete(int position);
}
